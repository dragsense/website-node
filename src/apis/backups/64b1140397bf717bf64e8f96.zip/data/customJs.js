// Define the two numbers
var num1 = 5;
var num2 = 10;

